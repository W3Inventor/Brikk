<div class="rz-modal rz-modal-listing-edit-booking-calendar" data-id="listing-edit-booking-calendar">
    <a href="#" class="rz-close">
        <i class="fas fa-times"></i>
    </a>
    <div class="rz-modal-heading rz--border">
        <h4 class="rz--title"><?php esc_html_e( 'Booking Calendar', 'routiz' ); ?></h4>
    </div>
    <div class="rz-modal-content">
        <div class="rz-modal-append"></div>
        <?php Rz()->preloader(); ?>
    </div>
</div>
