{!! do_shortcode( wpautop( html_entity_decode( wp_kses_post( ( $text ) ) ) ) ) !!}
