<?php

namespace Routiz\Inc\Src\Listing\Modules\Reviews;

use \Routiz\Inc\Src\Listing\Modules\Module;

class Reviews extends Module {

    // ..

}
