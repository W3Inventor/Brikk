<?php

namespace Routiz\Inc\Src\Form\Modules\Editor;

use \Routiz\Inc\Src\Form\Modules\Module;

class Editor extends Module {

    // ..

}
