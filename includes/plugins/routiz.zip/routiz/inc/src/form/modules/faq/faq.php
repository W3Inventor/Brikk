<?php

namespace Routiz\Inc\Src\Form\Modules\Faq;

use \Routiz\Inc\Src\Form\Modules\Module;

class Faq extends Module {

    // ..

}
