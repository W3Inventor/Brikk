<?php

namespace Routiz\Inc\Src\Form\Modules\Auto_Key;

use \Routiz\Inc\Src\Form\Modules\Module;

class Auto_Key extends Module {

    // ..

}
