<?php

namespace Routiz\Inc\Src\Form\Modules\Nonce;

use \Routiz\Inc\Src\Form\Modules\Module;

class Nonce extends Module {

    public function wrapper() {
        return '%3$s';
    }

}
