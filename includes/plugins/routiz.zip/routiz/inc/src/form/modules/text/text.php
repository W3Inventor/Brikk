<?php

namespace Routiz\Inc\Src\Form\Modules\Text;

use \Routiz\Inc\Src\Form\Modules\Module;

class Text extends Module {

    // ..

}
