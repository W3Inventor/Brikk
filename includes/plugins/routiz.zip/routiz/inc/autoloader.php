<?php

use \Routiz\Inc\Utils\Register;
use \Routiz\Inc\Utils\Helper;
use \Routiz\Inc\Utils\Icon;
use \Routiz\Inc\Utils\Notify;
use \Routiz\Inc\Utils\Notifications;
use \Routiz\Inc\Utils\Component_Manager;

if ( ! defined('ABSPATH') ) {
	exit;
}

/*
 * human readable dump
 *
 */
if( ! function_exists('dd') ) {
    function dd( $what = '' ) {
        print '<pre class="rz-dump">';
        print_r( $what );
        print '</pre>';
    }
}

/*
 * autoloader
 *
 */
spl_autoload_register( function( $class ) {

    if ( strpos( $class, 'Routiz' ) === false ) { return; }

    $file_parts = explode( '\\', $class );

    $namespace = '';
    for( $i = count( $file_parts ) - 1; $i > 0; $i-- ) {

        $current = strtolower( $file_parts[ $i ] );
        $current = str_ireplace( '_', '-', $current );

        if( count( $file_parts ) - 1 === $i ) {
            $file_name = "{$current}.php";
        }else{
            $namespace = '/' . $current . $namespace;
        }
    }

    $filepath  = trailingslashit( dirname( dirname( __FILE__ ) ) . $namespace );
    $filepath .= $file_name;

    if( file_exists( $filepath ) ) {
        include_once( $filepath );
    }

});

/*
 * register utils
 *
 */
if( ! function_exists('routiz') ) {
    function routiz() {
        return Register::instance();
    }
}

if( ! function_exists('Rz') ) {
    function Rz() {
    	return routiz()->helper();
    }
    routiz()->register( 'helper', Helper::instance() );
    routiz()->register( 'icon', Icon::instance() );
    routiz()->register( 'notify', Notify::instance() );
}


/* show custom user image on admin userlist */
add_filter( 'get_avatar_url', 'ayecode_get_avatar_url', 10, 3 );
function ayecode_get_avatar_url( $url, $id_or_email, $args ) {
  $id = '';
  if ( is_numeric( $id_or_email ) ) {
    $id = (int) $id_or_email;
  } elseif ( is_object( $id_or_email ) ) {
    if ( ! empty( $id_or_email->user_id ) ) {
      $id = (int) $id_or_email->user_id;
    }
  } else {
    $user = get_user_by( 'email', $id_or_email );
    $id = !empty( $user ) ?  $user->data->ID : '';
  }
  //Preparing for the launch.
  $user = new \Routiz\Inc\Src\User($id);
        $custom_url = $user->get_avatar();
  //$custom_url = $id ?  get_user_meta( $id, 'ayecode-custom-avatar', true ) : '';
  // If there is no custom avatar set, return the normal one.
  if( $custom_url == '' || !empty($args['force_default'])) {
    return esc_url_raw( get_template_directory_uri() . '/assets/dist/images/default-avatar.png' ); 
  }else{
    return esc_url_raw($custom_url);
  }
}



// Add Export and Import CSV Submenu under rz_listing_type
add_action('admin_menu', 'add_export_import_csv_submenu_items');
function add_export_import_csv_submenu_items() {
    // Export CSV submenu
    add_submenu_page(
        'edit.php?post_type=rz_listing_type',  // Parent slug (Custom Post Type)
        'Export CSV',                          // Page title
        '- Export CSV',                        // Menu title (with a '-' sign before it)
        'manage_options',                      // Capability
        'export-cpt-csv',                      // Menu slug
        'export_cpt_csv_page'                  // Callback function
    );

    // Import CSV submenu
    add_submenu_page(
        'edit.php?post_type=rz_listing_type',  // Parent slug (Custom Post Type)
        'Import CSV',                          // Page title
        '- Import CSV',                        // Menu title (with a '-' sign before it)
        'manage_options',                      // Capability
        'import-cpt-csv',                      // Menu slug
        'import_cpt_csv_page'                  // Callback function
    );
}

// Export CSV Page with Filter for rz_listing_type meta key
function export_cpt_csv_page() {
    // Get distinct rz_listing_type values from posts
    $args = array(
        'post_type'      => 'rz_listing_type', // Custom post type
        'posts_per_page' => -1,                // Get all posts
        'post_status'    => 'publish',         // Only published posts
        'orderby'        => 'title',           // Order by title
        'order'          => 'ASC',             // Ascending order
    );
 
    $listing_types_query = new WP_Query($args);
 
    echo '<div class="wrap"><h2>Export Listings CSV Format</h2>';
    echo '<form method="get" action="' . admin_url('admin-post.php') . '">';
    echo '<input type="hidden" name="action" value="export_custom_post_type_to_csv">';
    echo '<p><label for="listing_type">Select Listing Type to Export Format in CSV:</label><br>';
    echo '<select name="listing_type" id="listing_type" style="width: 100%; max-width: 400px;">';
    echo '<option value="">All Listing Types</option>';
 
    // Populate the dropdown with rz_listing_type post titles
    if ($listing_types_query->have_posts()) {
        while ($listing_types_query->have_posts()) {
            $listing_types_query->the_post();
            echo '<option value="' . get_the_ID() . '">' . get_the_title() . '</option>';
        }
    }
 
    echo '</select></p>';
    echo '<button type="submit" class="button-primary">Export CSV</button>';
    echo '</form>';
    echo '</div>';
 
    // Reset the post data after the query
    wp_reset_postdata();
}

// Handle Export CSV
function export_custom_post_type_to_csv() {
    // Validate user input
    $listing_type = isset($_GET['listing_type']) ? sanitize_text_field($_GET['listing_type']) : '';
    // Arguments for WP_Query
    $args = array(
        'post_type'      => 'rz_listing',
        'posts_per_page' => -1,
    );
    // Add meta query if a specific listing type is selected
    if (!empty($listing_type)) {
        $args['meta_query'] = array(
            array(
                'key'   => 'rz_listing_type',
                'value' => $listing_type,
                'compare' => '=', // Match the exact meta value
            ),
        );
    }
    // Query posts
    $query = new WP_Query($args);
    // If there are posts
    if ($query->have_posts()) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="rz-listing-export.csv"');
        $output = fopen('php://output', 'w');
        // Prepare CSV headers (including meta data)
        $headers = array('Title', 'Date', 'Content');
        // Fetch all meta keys from the first post
        $query->the_post();
        $post_id = get_the_ID();
        $meta_keys = get_post_custom_keys($post_id);
        // Include all meta keys
        if ($meta_keys) {
            foreach ($meta_keys as $meta_key) {
                $headers[] = $meta_key;
            }
        }
        // Output CSV headers
        fputcsv($output, $headers);
        // Reset and loop through posts again for data
        $query->rewind_posts();
        while ($query->have_posts()) {
            $query->the_post();
            $row = array(
                get_the_title(),
                get_the_date(),
                get_the_content(),
            );
            // Loop through meta keys for each post and get the values
            foreach ($meta_keys as $meta_key) {
                $meta_value = get_post_meta(get_the_ID(), $meta_key, true);
                $row[] = is_array($meta_value) ? implode(', ', $meta_value) : $meta_value;
            }
            // Output each row
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }
    wp_reset_postdata();
}
add_action('admin_post_export_custom_post_type_to_csv', 'export_custom_post_type_to_csv');

// Import CSV Page
function import_cpt_csv_page() {
    ?>
<div class="wrap">
<h2>Import Listings</h2>
	<?php if (isset($_GET['import']) && $_GET['import'] === 'success') : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e('CSV file imported successfully!', 'routiz'); ?></p>
            </div>
        <?php endif; ?>
<form method="post" enctype="multipart/form-data" action="<?php echo admin_url('admin-post.php'); ?>">
<input type="hidden" name="action" value="import_custom_post_type_from_csv">
<input type="file" name="import_csv_file" accept=".csv" required>
<?php submit_button('Upload and Import CSV'); ?>
</form>
</div>
<?php
}
 
// Handle Import CSV
add_action('admin_post_import_custom_post_type_from_csv', 'import_custom_post_type_from_csv');
function import_custom_post_type_from_csv() {
    // Log the start of the process
    error_log('Started CSV import process.');
 
    // Check if the file was uploaded without errors
    if (empty($_FILES['import_csv_file']) || $_FILES['import_csv_file']['error'] !== UPLOAD_ERR_OK) {
        wp_die('File upload failed: ' . ($_FILES['import_csv_file']['error'] ?? 'Unknown error'));
    }
 
    $csv_file = $_FILES['import_csv_file']['tmp_name'];
 
    // Log the file location
    error_log('Uploaded file path: ' . $csv_file);
 
    // Validate file type
    $file_extension = pathinfo($_FILES['import_csv_file']['name'], PATHINFO_EXTENSION);
    if (strtolower($file_extension) !== 'csv') {
        wp_die('Invalid file type. Please upload a valid CSV file with a .csv extension.');
    }
 
    // Optional: Check the first line of the file for valid CSV headers
    $first_line = fgets(fopen($csv_file, 'r'));
    if ($first_line === false || strpos($first_line, ',') === false) {
        wp_die('The uploaded file does not appear to be a valid CSV.');
    }
 
    // Open the file
    $handle = fopen($csv_file, 'r');
    if (!$handle) {
        wp_die('Could not open the uploaded CSV file.');
    }
 
    // Get the CSV headers
    $headers = fgetcsv($handle, 0, ',');
    if ($headers === false) {
        wp_die('Could not read headers from the CSV file.');
    }
 
    error_log('CSV Headers: ' . print_r($headers, true));
 
    // Define the custom post type
    $post_type = 'rz_listing';
 
    // Loop through each row in the CSV
    while (($row = fgetcsv($handle, 0, ',')) !== false) {
        $data = array_combine($headers, $row);
        if ($data === false) {
            error_log('Skipping row due to invalid data: ' . print_r($row, true));
            continue;
        }
 
        error_log('Processing row: ' . print_r($data, true));
 
        // Prepare post data
        $post_data = array(
            'post_title'   => $data['Title'] ?? 'Untitled',
            'post_content' => $data['Content'] ?? '',
            'post_type'    => $post_type,
            'post_status'  => 'publish',
        );
 
        // Insert or update the post
        if (!empty($data['ID'])) {
            $post_data['ID'] = $data['ID'];
            $post_id = wp_update_post($post_data);
        } else {
            $post_id = wp_insert_post($post_data);
        }
 
        // Check if the post was created or updated successfully
        if ($post_id && !is_wp_error($post_id)) {
            foreach ($data as $key => $value) {
                if (!in_array($key, ['ID', 'Title', 'Content', 'rz_gallery'])) {
                    update_post_meta($post_id, sanitize_key($key), sanitize_text_field($value));
                }
            }
 
            // Handle image gallery if 'Gallery URLs' is provided
            if (!empty($data['rz_gallery'])) {
                $gallery_urls = explode(',', $data['rz_gallery']); // URLs should be comma-separated
                $gallery_ids = [];
 
                foreach ($gallery_urls as $url) {
                    $attachment_id = upload_image_from_url(trim($url));
                    if ($attachment_id) {
                        $gallery_ids[] = ['id' => $attachment_id];
                    }
                }
 
                // Save the gallery meta as a JSON array
                update_post_meta($post_id, 'rz_gallery', wp_json_encode($gallery_ids));
            }
        } else {
            error_log('Failed to insert/update post: ' . print_r($post_data, true));
        }
    }
 
    fclose($handle);
 
    // Redirect back with a success message
    wp_redirect(admin_url('admin.php?page=import-cpt-csv&import=success'));
    exit;
}
 
// Function to upload an image from a URL
function upload_image_from_url($url) {
    $tmp = download_url($url);
    if (is_wp_error($tmp)) {
        error_log('Error downloading image: ' . $url);
        return false;
    }
 
    $file_array = [
        'name'     => basename($url),
        'tmp_name' => $tmp,
    ];
 
    // Use media_handle_sideload to sideload the image
    $attachment_id = media_handle_sideload($file_array, 0);
 
    // Cleanup temporary file
    @unlink($tmp);
 
    if (is_wp_error($attachment_id)) {
        error_log('Error sideloading image: ' . $url);
        return false;
    }
 
    return $attachment_id;
}





/*
 * initializer
 *
 */
Routiz\Inc\Init::instance();
