<div class="brk-boxed">
    <div class="brk-no-results">
        <p><?php esc_html_e( 'We could not find any results for your search. You can give it another try through the search form below.', 'brikk' ); ?></p>
    </div>
    <?php get_search_form(); ?>
</div>

