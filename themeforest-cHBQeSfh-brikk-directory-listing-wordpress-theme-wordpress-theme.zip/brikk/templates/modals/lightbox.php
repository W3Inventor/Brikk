<div class="rz-modal rz-modal-lightbox rz-no-select" data-id="lightbox">
    <a href="#" class="rz-close">
        <i class="fas fa-times"></i>
    </a>
    <div class="rz-modal-heading">
        <h4 class="rz--title">&nbsp;</h4>
    </div>
    <div class="rz-modal-content">
        <div class="rz-modal-image">
            <!-- append immage here -->
        </div>
        <a href="#" class="rz-lightbox-nav" data-action="prev">
            <span><i class="fas fa-arrow-left"></i></span>
        </a>
        <a href="#" class="rz-lightbox-nav" data-action="next">
            <span><i class="fas fa-arrow-right"></i></span>
        </a>
        <?php Rz()->preloader(); ?>
    </div>
    <div class="rz-lightbox-counter">
        <span class="rz--current"></span>&nbsp;&sol;&nbsp;<span class="rz--total"></span>
    </div>
</div>
