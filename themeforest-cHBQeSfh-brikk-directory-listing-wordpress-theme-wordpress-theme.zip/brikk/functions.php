<?php

/*
 * call the framework
 *
 */
require get_template_directory() . '/includes/autoload.php';


